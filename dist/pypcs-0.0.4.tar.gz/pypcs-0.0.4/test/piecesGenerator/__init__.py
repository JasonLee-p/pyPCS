"""
piecesGenerator
===============
This package defines the way to generate tiny pieces.
"""
