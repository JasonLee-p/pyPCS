from ..basicGenerator import *
from ..series import MainTree, PitchSeries, Rhythm, PitchSegment


class Sheet:
    def __init__(self):
        pass


class PiecesGenerator:
    def __init__(self):
        self.mainTree = MainTree()
        self.tonality = 0
        self.structure = 0
