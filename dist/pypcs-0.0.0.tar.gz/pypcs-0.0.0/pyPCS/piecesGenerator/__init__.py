"""
piecesGenerator
===============
This package defines the way to generate tiny pieces.
"""

from .pieces_generator import *

__all__ = [

]
